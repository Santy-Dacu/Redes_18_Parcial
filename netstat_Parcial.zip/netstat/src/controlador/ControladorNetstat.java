package controlador;

import modelo.NetstatModelo;

public class ControladorNetstat {
    private final NetstatModelo netstatModelo;

    public ControladorNetstat() {
        this.netstatModelo = new NetstatModelo();
    }

    public String ejecutarNetstatParcial() {
        return netstatModelo.ejecutarNetstatParcial();
    }
}
