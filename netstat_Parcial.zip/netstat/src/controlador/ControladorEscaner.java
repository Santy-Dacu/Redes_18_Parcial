package controlador;

import modelo.Escaner;
import modelo.Equipo;
import modelo.ValidadorIP;

import javax.swing.DefaultListModel;
import java.util.List;

public class ControladorEscaner {
    private final Escaner escaner;
    private final ValidadorIP validador;

    public ControladorEscaner() {
        this.escaner = new Escaner();
        this.validador = new ValidadorIP();
    }

    public boolean esIPValida(String ip) {
        return validador.esValida(ip);
    }

    public List<Equipo> escanear(String inicio, String fin, javax.swing.JProgressBar barra) {
        return escaner.escanearRango(inicio, fin, barra);
    }

    public DefaultListModel<Equipo> escanearComoListModel(String inicio, String fin, javax.swing.JProgressBar barra) {
        DefaultListModel<Equipo> modeloLista = new DefaultListModel<>();
        List<Equipo> equipos = escanear(inicio, fin, barra);
        for (Equipo eq : equipos) {
            modeloLista.addElement(eq);
        }
        return modeloLista;
    }
}
