package vista;

import controlador.ControladorNetstat;

import javax.swing.*;

public class VentanaNetstat extends JFrame {
    private JButton btnNetstat;
    private JTextArea areaNetstat;
    private ControladorNetstat controlador;

    public VentanaNetstat() {
        setTitle("Netstat (Versión Parcial)");
        setSize(700, 500);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null);

        controlador = new ControladorNetstat();

        btnNetstat = new JButton("Ejecutar Netstat -ano");
        btnNetstat.setBounds(20, 20, 200, 30);
        add(btnNetstat);

        areaNetstat = new JTextArea();
        areaNetstat.setEditable(false);
        JScrollPane scroll = new JScrollPane(areaNetstat);
        scroll.setBounds(20, 70, 640, 350);
        add(scroll);

        btnNetstat.addActionListener(e -> {
            String resultado = controlador.ejecutarNetstatParcial();
            areaNetstat.setText(resultado);
        });
    }
}
