package vista;

import javax.swing.*;

public class VentanaPrincipal extends JFrame {
    private JButton btnEscaner;
    private JButton btnNetstat;

    public VentanaPrincipal() {
        setTitle("Menú Principal");
        setSize(400, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null);

        btnEscaner = new JButton("Abrir Escáner de Red");
        btnEscaner.setBounds(80, 40, 220, 30);
        add(btnEscaner);

        btnNetstat = new JButton("Abrir Netstat");
        btnNetstat.setBounds(80, 90, 220, 30);
        add(btnNetstat);

        btnEscaner.addActionListener(e -> new VentanaEscaner().setVisible(true));
        btnNetstat.addActionListener(e -> new VentanaNetstat().setVisible(true));

        setVisible(true);
    }
}
