/**
 * 
 */
/**
 * 
 */
module netstat {
	requires java.desktop;
}